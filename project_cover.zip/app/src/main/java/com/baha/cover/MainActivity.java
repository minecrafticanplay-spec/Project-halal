package com.baha.cover;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    TextView status;
    Button toggle;
    SharedPreferences sp;

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView tv(String t, int size, boolean bold) {
        TextView x = new TextView(this);
        x.setText(t);
        x.setTextSize(size);
        x.setTextColor(Color.WHITE);
        x.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        x.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        if (bold) x.setTypeface(null, android.graphics.Typeface.BOLD);
        x.setPadding(0, dp(8), 0, dp(4));
        return x;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", 0);
        getWindow().setStatusBarColor(Color.parseColor("#0f172a"));
        getWindow().setNavigationBarColor(Color.parseColor("#0f172a"));

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0f172a"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        sv.addView(root);

        root.addView(tv("مغطّي الصور والفيديو", 22, true));
        status = tv("", 15, true);
        root.addView(status);

        root.addView(tv("1) فعّل الخدمة: إعدادات إمكانية الوصول ← التطبيقات المثبّتة ← مغطّي الصور والفيديو ← تشغيل.", 14, false));
        Button acc = new Button(this);
        acc.setText("فتح إعدادات إمكانية الوصول");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        root.addView(tv("إذا كان الخيار رماديًا (أندرويد 13 فأحدث): افتح معلومات التطبيق، ثم ⋮ ← السماح بالإعدادات المقيّدة، ثم ارجع وفعّل الخدمة.", 13, false));
        Button info = new Button(this);
        info.setText("فتح معلومات التطبيق");
        info.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        root.addView(info);

        root.addView(tv("2) الحد الأدنى لحجم الصورة المغطّاة (بالـ dp). الأصغر منه، مثل الأيقونات، لا يُغطّى:", 14, false));
        final EditText min = new EditText(this);
        min.setInputType(InputType.TYPE_CLASS_NUMBER);
        min.setTextColor(Color.WHITE);
        min.setText(String.valueOf(sp.getInt("min", 96)));
        root.addView(min);
        Button save = new Button(this);
        save.setText("حفظ");
        save.setOnClickListener(v -> {
            int m = 96;
            try { m = Integer.parseInt(min.getText().toString().trim()); } catch (Exception e) { }
            sp.edit().putInt("min", Math.max(20, m)).apply();
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show();
        });
        root.addView(save);

        toggle = new Button(this);
        toggle.setOnClickListener(v -> {
            sp.edit().putBoolean("on", !sp.getBoolean("on", true)).apply();
            refresh();
        });
        root.addView(toggle);

        root.addView(tv("طريقة الاستخدام: تُغطّى الصور والفيديوهات تلقائيًا، واضغط على أي غطاء مرتين لإظهاره. السحب على الغطاء يمرّر الصفحة. بمجرد الانتقال إلى تطبيق آخر تُغطّى الصور من جديد.", 13, false));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    void refresh() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean en = s != null && s.contains(getPackageName() + "/");
        boolean on = sp.getBoolean("on", true);
        status.setText(en ? (on ? "الحالة: الخدمة مفعّلة والتغطية تعمل ✅" : "الحالة: الخدمة مفعّلة لكن التغطية متوقفة ⏸")
                : "الحالة: الخدمة غير مفعّلة ❌");
        toggle.setText(on ? "إيقاف التغطية مؤقتًا" : "تشغيل التغطية");
    }
}
