package com.baha.cover;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CoverService extends AccessibilityService {
    static class Item {
        AccessibilityNodeInfo node;
        Rect r;
        String key;
    }

    static final String[] KEYS = {"photo", "video", "image", "picture", "gif", "صورة", "صوره", "فيديو", "مقطع"};

    WindowManager wm;
    final Handler h = new Handler(Looper.getMainLooper());
    final List<Cover> covers = new ArrayList<>();
    final Set<String> revealed = new HashSet<>();
    String lastPkg = "";
    long lastRun = 0;
    boolean pending = false;
    float dp = 1f;
    int sw, sh;

    final Runnable runner = new Runnable() {
        public void run() {
            pending = false;
            lastRun = SystemClock.uptimeMillis();
            try { update(); } catch (Exception e) { }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        dp = getResources().getDisplayMetrics().density;
        schedule(0);
    }

    void schedule(long gap) {
        if (pending) return;
        long wait = Math.max(0, gap - (SystemClock.uptimeMillis() - lastRun));
        pending = true;
        h.postDelayed(runner, wait);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null) return;
        schedule(e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED ? 25 : 120);
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        clearAll();
        super.onDestroy();
    }

    void clearAll() {
        for (Cover c : covers) c.detach();
    }

    boolean isMedia(AccessibilityNodeInfo n) {
        String c = n.getClassName() == null ? "" : n.getClassName().toString();
        if (c.contains("ImageView") || c.equals("android.widget.Image") || c.contains("VideoView")
                || c.contains("SurfaceView") || c.contains("TextureView") || c.contains("PlayerView")
                || c.contains("VideoPlayer") || c.contains("ExoPlayer")) return true;
        if (n.isScrollable() || c.endsWith("Layout") || c.contains("Recycler") || c.contains("ListView")
                || c.contains("Grid") || c.contains("Pager") || c.contains("ScrollView") || c.contains("WebView"))
            return false;
        CharSequence d = n.getContentDescription();
        if (d == null) return false;
        String s = d.toString().toLowerCase();
        for (String k : KEYS) if (s.contains(k)) return true;
        return false;
    }

    void update() {
        if (wm == null) return;
        android.content.SharedPreferences sp = getSharedPreferences("cfg", 0);
        if (!sp.getBoolean("on", true)) { clearAll(); return; }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        String pk = root.getPackageName() == null ? "" : root.getPackageName().toString();
        if (pk.equals(getPackageName()) || pk.equals("com.android.systemui")) { clearAll(); return; }
        if (!pk.equals(lastPkg)) { revealed.clear(); lastPkg = pk; }
        int minPx = Math.round(sp.getInt("min", 96) * dp);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;

        List<Item> vis = new ArrayList<>();
        ArrayDeque<AccessibilityNodeInfo> st = new ArrayDeque<>();
        st.push(root);
        int cnt = 0;
        while (!st.isEmpty() && cnt < 3000) {
            AccessibilityNodeInfo n = st.pop();
            cnt++;
            if (!n.isVisibleToUser()) continue;
            if (isMedia(n)) {
                Rect r = new Rect();
                n.getBoundsInScreen(r);
                if (r.intersect(0, 0, sw, sh) && r.width() >= minPx && r.height() >= minPx) {
                    String key = pk + "#" + n.hashCode() + "#" + r.width() + "x" + r.height();
                    if (!revealed.contains(key)) {
                        Item it = new Item();
                        it.node = n;
                        it.r = r;
                        it.key = key;
                        vis.add(it);
                    }
                    continue;
                }
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) st.push(c);
            }
        }
        render(vis);
    }

    void render(List<Item> vis) {
        while (covers.size() < vis.size()) covers.add(new Cover());
        for (int i = 0; i < covers.size(); i++) {
            Cover c = covers.get(i);
            if (i < vis.size()) c.bind(vis.get(i));
            else c.detach();
        }
    }

    class Cover extends View {
        Item item;
        WindowManager.LayoutParams lp;
        boolean attached = false;
        float dx, dy;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final GestureDetector gd;

        Cover() {
            super(CoverService.this);
            p.setColor(0xFF9CA3AF);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(13 * dp);
            lp = new WindowManager.LayoutParams(10, 10,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.LEFT;
            gd = new GestureDetector(CoverService.this, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    if (item != null) {
                        revealed.add(item.key);
                        schedule(0);
                    }
                    return true;
                }
            });
        }

        void bind(Item it) {
            item = it;
            boolean changed = lp.x != it.r.left || lp.y != it.r.top
                    || lp.width != it.r.width() || lp.height != it.r.height();
            lp.x = it.r.left;
            lp.y = it.r.top;
            lp.width = it.r.width();
            lp.height = it.r.height();
            try {
                if (!attached) {
                    wm.addView(this, lp);
                    attached = true;
                } else if (changed) {
                    wm.updateViewLayout(this, lp);
                }
            } catch (Exception e) { }
            invalidate();
        }

        void detach() {
            if (attached) {
                try { wm.removeView(this); } catch (Exception e) { }
                attached = false;
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0xFF1A1A1A);
            if (getWidth() > 130 * dp && getHeight() > 60 * dp) {
                c.drawText("اضغط مرتين للإظهار", getWidth() / 2f, getHeight() / 2f, p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            gd.onTouchEvent(e);
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                dx = e.getRawX();
                dy = e.getRawY();
            } else if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                if (Math.hypot(mx, my) > 40 * dp) scrollUnder(mx, my);
            }
            return true;
        }

        void scrollUnder(float mx, float my) {
            if (item == null) return;
            AccessibilityNodeInfo n = item.node;
            n.refresh();
            AccessibilityNodeInfo.AccessibilityAction act;
            boolean vertical = Math.abs(my) >= Math.abs(mx);
            if (vertical) act = my < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN
                    : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
            else act = mx < 0 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT
                    : AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
            boolean forward = vertical ? my < 0 : mx < 0;
            AccessibilityNodeInfo p = n.getParent();
            AccessibilityNodeInfo fallback = null;
            while (p != null) {
                if (p.getActionList().contains(act)) {
                    p.performAction(act.getId());
                    return;
                }
                if (fallback == null && p.isScrollable()) fallback = p;
                p = p.getParent();
            }
            if (fallback != null) {
                fallback.performAction(forward ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                        : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            }
        }
    }
}
